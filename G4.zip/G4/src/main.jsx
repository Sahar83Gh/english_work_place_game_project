import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import EnglishWorkplaceGame from './EnglishWorkplaceGame.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <EnglishWorkplaceGame />
  </StrictMode>,
)
